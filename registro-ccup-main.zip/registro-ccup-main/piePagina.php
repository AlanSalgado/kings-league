<footer class="footer mt-auto py-2 fixed-bottom">
        <div class="row text-center">
            <span class="py-0 fs-5"><b>Contacto</b></span>
            <a href="#" class="py-1"><i class="bi bi-envelope-fill"> example@gmail.com</i></a>
            <a href="#" class="py-1"><i class="bi bi-telephone-fill"> 445-XXX-XX-XX</i></a>
        </div>
</footer>