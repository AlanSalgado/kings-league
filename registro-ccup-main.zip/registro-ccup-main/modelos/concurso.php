<?php
    class concurso {
        public $idConcurso = 0;
        public $nombreConcurso = "";
        public $fechaInicio = "";
        public $fechaFin = "";
        public $ubicacion = "";
        public $status = 0;
    }
?>