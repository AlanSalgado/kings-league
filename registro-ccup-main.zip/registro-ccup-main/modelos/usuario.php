<?php
    class usuario{
        public $idUsuario=0;
        public $nombre="";
        public $usuario="";
        public $correo="";
        public $telefono="";
        public $password="";
        public $idInstitucion=1;
        public $tipoUsuario=3;
    }
?>