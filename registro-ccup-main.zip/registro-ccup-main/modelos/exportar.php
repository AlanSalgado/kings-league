<?php
    class exportar {
        public $nombreEquipo = "";
        public $coach = "";
        public $institucion = "";
        public $estudiante1 = "";
        public $estudiante2 = "";
        public $estudiante3 = "";
    }
?>