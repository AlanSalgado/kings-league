<?php
    class institucion {
        public $idInstitucion = 0;
        public $nombre = "";
    }
?>