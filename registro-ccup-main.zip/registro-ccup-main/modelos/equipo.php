<?php
    class equipo {
        public $idUsuario = 0;
        public $idEquipo = 0;
        public $nombre = "";
        public $idConcurso = 0;
        public $aprobado = 0;
        public $estudiante1 = "";
        public $estudiante2 = "";
        public $estudiante3 = "";
    }
?>